﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Web.Api.Infrastructure"), InternalsVisibleTo("Web.Api.Core.UnitTests")]